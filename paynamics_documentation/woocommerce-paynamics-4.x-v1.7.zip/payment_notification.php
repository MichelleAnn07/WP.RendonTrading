<?php

session_start();

require_once('wp-config.php');

try {
    $body = $_POST['paymentresponse'];

    echo "INITIAL DATA : " . $body;

    $base64 = str_replace(" ", "+", $body);
    $body = base64_decode($base64); // this will be the actual xml
    $data = simplexml_load_string($body);

    echo "<br/><br/>RECEIVED DATA : " . $body;
    echo "<br/><br/>RESPONSE CODE : " . $data->responseStatus->response_code;
    echo "<br/><br/>PNX ORDER ID : " . $data->application->request_id;
    echo "<br/>";

    if (WC()->payment_gateways()) {
        $payment_gateways = WC()->payment_gateways->payment_gateways();
    } else {
        $payment_gateways = array();
    }
    $payment_method = !empty($order->payment_method) ? $order->payment_method : 'paynamics';

    $order_id = "";

    if ($payment_gateways[$payment_method]->get_option('sandbox') == "yes") {
        $mkey = $payment_gateways[$payment_method]->get_option('test_mkey');
        $order_id = substr($data->application->request_id, 11);
    } else {
        $mkey = $payment_gateways[$payment_method]->get_option('live_mkey');
        $order_id = $data->application->request_id;
    }

    echo "<br/><br/>WOO ORDER ID : " . $order_id;

    $order = wc_get_order(absint($order_id));

    try {

        if (!empty($order))
        {
            //log Paygate response
            $note = "Incoming Paynamics Payment Response\n";
            $note = $note . "Response ID: " . $data->application->response_id . "\n";
            $note = $note . "Response Code: " . $data->responseStatus->response_code . "\n";
            $note = $note . "Response Message: " . $data->responseStatus->response_message . "\n";

            $forSign = $data->application->merchantid . $data->application->request_id . $data->application->response_id . $data->responseStatus->response_code . $data->responseStatus->response_message . $data->responseStatus->response_advise . $data->application->timestamp . $data->application->rebill_id;
            $cert = $mkey; //<-- your merchant key
            $_sign = hash("sha512", $forSign . $cert);

            echo "<br/><br/>signedXMLResponse: " . $data->application->signature;
            echo "<br/><br/>Signature : " . $_sign;
            //if signature verified and equal, update database
            //query and update here

            if ($data->application->signature == $_sign) {

                $note = $note . "\nExisting Order Status: " . $order->get_status();

                echo "<br/><br/>Existing Order Status : " . $order->get_status();

                if ($order->get_status() == "processing" || $order->get_status() == "completed")
                {
                    $note = $note . "\nOrder update failed.";

                    echo "<br/><br/>Do not update.";
                }
                else
                {
                    // check if successful payment
                    if ($data->responseStatus->response_code == 'GR001' || $data->responseStatus->response_code == 'GR002') {
                        echo "<br/><br/>GR001 or GR002";
                        //update here
                        // Payment complete
                        $order->payment_complete();
                    } // check if pending payment
                    else if ($data->responseStatus->response_code == 'GR033') {
                        echo "<br/><br/>PENDING";
                        //update here
                        $order->update_status(apply_filters('wc_ppg_default_order_status', 'on-hold'), __('Awaiting payment', 'wc_ppg'));
                    } // check if payment was cancelled
                    else if ($data->responseStatus->response_code == 'GR053') {
                        echo "<br/><br/>CANCELLED";
                        //update here
                        $order->update_status(apply_filters('wc_ppg_default_order_status', 'cancelled'), __('Cancelled payment', 'wc_ppg'));
                    } //check if failed payment
                    else {
                        echo "<br/><br/>FAILED";
                        //update here
                        $order->update_status(apply_filters('wc_ppg_default_order_status', 'failed'), __('Payment failed', 'wc_ppg'));
                    }

                    $note = $note . "\n\nOrder status updated.";
                    echo "<br/><br/>Order status updated.";
                }

                //add_action( 'woocommerce_checkout_update_order_meta', 'my_custom_checkout_field_update_order_meta', $order_id, $data->application->response_id );
                echo "<br/><br/>Save Response ID: " . $data->application->response_id;
                update_post_meta( $order_id, '_paynamics_response_id', stripslashes($data->application->response_id), true );
                
            } else {
             $note = "\nSignatures don't match.";
             $note = $note . "\nOrder update failed.";

             echo "<br/><br/>Signatures don't match.";
         }

            //add order note
         $order->add_order_note( $note );
     }
     else
     {
        echo "<br/><br/>Order not found.";
    }
} catch (Exception $ex) {
    echo $ex;
}
} catch (Exception $ex) {
    echo $ex;
}

/**
 * Update the order meta with field value
 */
function my_custom_checkout_field_update_order_meta( $order_id, $response_id ) {
    if ( empty( $_POST['paynamics_response_id'] ) ) {
        update_post_meta( $order_id, 'paynamics_response_id', sanitize_text_field( $response_id ) );
    }
}