Paynamics Payment WooCommerce Extension
WooCommerce v4.0.1

Note:
1. Install the zip file 'woocommerce-paynamics.zip' to Wordpress plugins installer and activate.

2. WooCommerce Payment Gateway Settings
 - Configure the merchant credentials in the admin panel (WooCommerce > Settings > Payments > Paynamics Payment Gateway).
 - Merchant ID, key and URL will be provided by your contact person.
 - Confirm with your contact person the Web Payment Frontend URL you need to use. Default is: https://testpti.payserv.net/webpayment/default.aspx

4. Notification Receiver (payment_notification.php)
 - Upload 'payment_notification.php' to Wordpress root directory. 
 - ex. http://localhost/wordpress/payment_notification.php
 - Make sure the URL is accessible to be able to receive POST data from Paynamics notification system.